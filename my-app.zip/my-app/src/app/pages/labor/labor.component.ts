import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-labor',
  templateUrl: './labor.component.html',
  styleUrls: ['./labor.component.css']
})
export class LaborComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  createLabor(): void {
    window.location.href="labor/create"
  }

}
