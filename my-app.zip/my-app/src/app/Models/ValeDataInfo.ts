export interface ValeDataInfo {
    operador_Name:String;
    unidad_Code:String;
    unidad_Name: String;
    km_Inicial:number;
    rendimiento_Optimo:number;
    proveedor:String;
    usuario:String;
    sucursal:String;
    tanqueLLeno: string
}