import { AutoAbastoRequest } from "./AutoAbastoRequest";

export interface OrdenCompraRequest extends AutoAbastoRequest{
    
}