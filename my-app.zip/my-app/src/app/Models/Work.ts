export interface Work {
    id: number
    empresa: string,
    cardCode: string,
    cardName: string,
    descripcion: string,
    oficio: string,
    costoXhora: number,
    timestamp: string
}