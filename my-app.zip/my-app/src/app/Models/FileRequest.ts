export interface FileRequest {
    empresa: number, 
    keySAPid: number, 
    fileName: string,
    file64: string
}