export interface LoginResponse {    
   token:String;   
}