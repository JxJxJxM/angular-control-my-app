export interface DatabaseInfo {
    id:number;
    name:String;
    description:String;
}