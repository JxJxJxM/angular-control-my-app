export interface Rol {
    id:number;
    name:String;
}