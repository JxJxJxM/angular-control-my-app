export interface Usuario {
    id:number;
    idrol:number;
    roles:String;
    namerol:String;
    name:String;
    email:String;
    password:String;
}