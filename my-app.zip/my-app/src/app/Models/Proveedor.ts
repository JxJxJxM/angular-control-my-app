export interface Proveedor {
    cardCode:String;
    cardName:String;
    empresa:String;
    
}