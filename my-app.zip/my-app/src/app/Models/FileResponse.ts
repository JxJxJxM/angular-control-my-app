export interface FileResponse {
    path: string,
    absEntry: number,
    keySapID: number,
    empresa: string,
    fileName: string
}