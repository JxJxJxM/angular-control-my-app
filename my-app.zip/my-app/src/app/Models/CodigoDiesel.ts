export interface CodigoDiesel {    
    itemcode:String;
    itemName:String;
    tipo:String;
    empresa:String;
    
}