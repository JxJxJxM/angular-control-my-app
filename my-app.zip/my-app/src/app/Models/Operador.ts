export interface Operador {
    code:String;
    name:String;
    docEntry:number;
    u_TLic:String;
    u_NLic:String;
    u_VLic:String;
}