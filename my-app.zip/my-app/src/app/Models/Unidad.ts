export interface Unidad {
    itemcode:String;
    itemname:String;
    operador:String;
    telefono:String;
    tipo:String;
    sucursal:String;
    odometro_Final:number;
    rendimiento_Anterior:number;
    rendimiento:number;
    empresa:String;
    nombreEmpresa:String;
    isHrs:String;
    acom:String;
}
