export interface StockDieselILM {
    stock:String,
    onHand:number,
    itemCode:String,
    whsCode:String,
    stockTotal:number,
    empresa:String,
}