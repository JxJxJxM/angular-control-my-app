export interface DocumentLine {
    ItemCode:String;
    Quantity:number;
}