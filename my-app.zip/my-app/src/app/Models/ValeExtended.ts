import { Vale } from "./Vale";

export interface ValeExtended extends Vale {
    isLast:boolean;

}