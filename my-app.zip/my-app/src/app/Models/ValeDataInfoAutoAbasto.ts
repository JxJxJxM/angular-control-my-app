import { ValeDataInfo } from "./ValeDataInfo";

export interface ValeDataInfoAutoAbasto extends ValeDataInfo {
    Lbomba_Inicial:number;
}