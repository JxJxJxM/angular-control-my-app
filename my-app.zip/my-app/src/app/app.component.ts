import { Component } from '@angular/core';
import { AutoAbastoRequest } from './Models/AutoAbastoRequest';
import { DocumentLine } from './Models/DocumentLine';
import { ValeDataInfo } from './Models/ValeDataInfo';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Control de combustible';

}
