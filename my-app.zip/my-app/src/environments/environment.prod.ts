export const environment = {
  production: true,
  sapServiceBaseUrl: "http://localhost:8084/",
  reportsServiceBaseUrl: "http://localhost:8081/"
};
